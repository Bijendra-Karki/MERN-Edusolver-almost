// paymentController.js
import Payment from "../models/paymentModel.js";
import Enrollment from "../models/enrollmentModel.js";
import Subject from "../models/subjectModel.js";
import crypto from "crypto";
import { Types } from "mongoose";
import axios from "axios"; // Required for server-to-server verification

// --- Configuration Constants ---
// NOTE: Ensure these environment variables are correctly set in your .env file
const FRONTEND_SUCCESS_URL =
  process.env.FRONTEND_SUCCESS_URL || "http://localhost:5173/payment-success";
const FRONTEND_FAILURE_URL =
  process.env.FRONTEND_FAILURE_URL || "http://localhost:5173/payment-failure";
const ESEWA_SECRET_KEY = process.env.ESEWA_SECRET_KEY;
const ESEWA_PRODUCT_CODE = process.env.ESEWA_PRODUCT_CODE || "EPAYTEST";
const ESEWA_VERIFICATION_URL =
  process.env.NODE_ENV === "production"
    ? "https://epay.esewa.com.np/api/epay/main/v2/transaction/status" // Production URL
    : "https://uat.esewa.com.np/api/epay/main/v2/transaction/status"; // Test URL

// -----------------------------------------------------------
// 1. ESEWA SIGNATURE GENERATION (Internal Utility)
// -----------------------------------------------------------
const generateEsewaSignature = ({
  total_amount,
  transaction_uuid,
  product_code,
}) => {
  const dataToSign = `total_amount=${total_amount},transaction_uuid=${transaction_uuid},product_code=${product_code}`;

  if (!ESEWA_SECRET_KEY) {
    throw new Error("ESEWA_SECRET_KEY is not configured.");
  }

  const signature = crypto
    .createHmac("sha256", ESEWA_SECRET_KEY)
    .update(dataToSign)
    .digest("base64");

  return signature;
};

// -----------------------------------------------------------
// 2. INITIATE PAYMENT & GENERATE SIGNATURE
// -----------------------------------------------------------
// POST: /api/payments/initiate (Auth needed: requireSignin)
export const initiatePayment = async (req, res) => {
  const userId = req.auth._id;
  const { subjectId, amount } = req.body;

  // Basic Input Validation
  if (!subjectId || !amount || isNaN(amount) || amount <= 0) {
    return res.status(400).json({ message: "Invalid subject ID or amount." });
  }
  if (!Types.ObjectId.isValid(subjectId)) {
    return res.status(400).json({ message: "Invalid Subject ID format." });
  }

  try {
    // Step 1: Verify Subject and actual price (Security Check)
    const subject = await Subject.findById(subjectId);

    if (!subject) {
      return res.status(404).json({ message: "Subject not found." });
    }

    // Convert both values to two decimal places (fixed-point string) for reliable comparison
    const receivedAmount = parseFloat(amount).toFixed(2);
    const subjectPrice = parseFloat(subject.price).toFixed(2);

    if (receivedAmount !== subjectPrice) {
      console.error(
        `Price mismatch: Received ${receivedAmount}, Expected ${subjectPrice} for Subject ID: ${subjectId}`
      );
      return res
        .status(400)
        .json({ message: "Subject or price mismatch detected." });
    }

    // Step 2: Generate a unique ID for this transaction (Your internal UUID)
    const newPaymentId = new Types.ObjectId();
    const transaction_uuid = newPaymentId.toHexString(); // Use the _id as the uuid

    // Step 3: Create the Pending Payment Record in your DB
    const newPayment = new Payment({
      _id: newPaymentId,
      user_id: userId,
      subject_id: subjectId,
      amount: amount,
      method: "eSewa",
      status: "pending",
      verification_status: "unverified",
    });
    // FIX: Removed duplicate save() call
    await newPayment.save();

    // Step 4: Prepare eSewa Form Data
    const formData = {
      amount: amount,
      tax_amount: 0,
      total_amount: amount,
      transaction_uuid: transaction_uuid,
      product_code: ESEWA_PRODUCT_CODE,
      product_service_charge: 0,
      product_delivery_charge: 0,
      // NOTE: success_url is the endpoint eSewa hits with the transaction details
      success_url: FRONTEND_SUCCESS_URL,
      failure_url: FRONTEND_FAILURE_URL,
      signed_field_names: "total_amount,transaction_uuid,product_code",
    };

    // Step 5: Generate eSewa Signature
    const signature = generateEsewaSignature(formData);

    // Step 6: Send back formData and signature to the client
    res.status(200).json({
      message: "Payment initiated successfully.",
      formData: formData,
      signature: signature,
    });
  } catch (error) {
    console.error("Error during payment initiation:", error);
    res
      .status(500)
      .json({ message: "Failed to initiate payment.", error: error.message });
  }
};

// -----------------------------------------------------------
// 3. ESEWA PAYMENT VERIFICATION UTILITY (CRITICAL FIX)
// -----------------------------------------------------------

/**
 * Decodes the Base64 data received from eSewa and calls the eSewa API for verification.
 * NOTE: This is the actual implementation that was missing.
 */
const verifyEsewaPayment = async (eSewaResponseData) => {
  try {
    // 1. Decode eSewaResponseData (Base64)
    const decodedData = Buffer.from(eSewaResponseData, "base64").toString(
      "utf8"
    );
    const responseJson = JSON.parse(decodedData);
    
    // Extract required fields from the decoded response
    const refId = responseJson.transaction_code; // eSewa's transaction ID
    const orderId = responseJson.transaction_uuid; // Our unique payment ID

    if (!refId || !orderId) {
      console.error("eSewa response missing transaction codes.");
      return { isVerified: false, refId: null, orderId: null };
    }

    // 2. Call eSewa's Server-to-Server Verification API
    const verificationPayload = {
      product_code: ESEWA_PRODUCT_CODE,
      transaction_uuid: orderId,
    };
    
    // Create the signature for the verification payload
    const verificationSignature = generateEsewaSignature(verificationPayload);

    const apiResponse = await axios.post(
      ESEWA_VERIFICATION_URL,
      {
        amount: 0, // Not strictly required for status check, but good to include
        ...verificationPayload
      },
      {
        headers: {
          "Content-Type": "application/json",
          "signature": verificationSignature // The signature for the server call
        }
      }
    );

    const status = apiResponse.data.status;
    const isSuccess = status === "COMPLETE" || status === "VERIFIED";

    if (isSuccess) {
        console.log(`eSewa verification successful for order: ${orderId}`);
    } else {
        console.warn(`eSewa verification failed. Status: ${status}`);
    }

    return {
      isVerified: isSuccess,
      refId: refId,
      orderId: orderId,
    };
    
  } catch (error) {
    console.error("Error during eSewa API verification:", error.message);
    return { isVerified: false, refId: null, orderId: null };
  }
};


// -----------------------------------------------------------
// 4. ESEWA PAYMENT VERIFICATION ENDPOINT
// -----------------------------------------------------------
// GET: /api/payments/verify (No auth needed, called by eSewa redirect)
export const verifyPaymentAndEnroll = async (req, res) => {
  const { data: eSewaResponseData } = req.query;

  if (!eSewaResponseData) {
    // eSewa sends no data if transaction is cancelled by user
    return res.redirect(`${FRONTEND_FAILURE_URL}?msg=TransactionCancelled`);
  }

  try {
    // Call the crucial verification utility
    const verificationResult = await verifyEsewaPayment(eSewaResponseData);

    const { isVerified, refId, orderId } = verificationResult;

    // Fetch the pending payment record from our DB
    const payment = await Payment.findById(orderId);
    if (!payment) {
      return res.redirect(
        `${FRONTEND_FAILURE_URL}?msg=PaymentNotFound&uuid=${orderId}`
      );
    }
    
    // Update Payment Record based on verification result
    if (isVerified) {
      payment.status = "completed";
      payment.verification_status = "verified";
      payment.gateway_ref_id = refId;
    } else {
      payment.status = "failed";
      payment.verification_status = "invalid_data";
      // Ensure failed payments still save the reference ID if available
      if (refId) payment.gateway_ref_id = refId; 
    }
    await payment.save();

    if (isVerified) {
      // Check for existing enrollment to prevent duplicates
      let enrollment = await Enrollment.findOne({
        user_id: payment.user_id,
        subject_id: payment.subject_id,
      });

      if (!enrollment) {
        enrollment = new Enrollment({
          user_id: payment.user_id,
          subject_id: payment.subject_id,
          payment_id: payment._id,
          access_status: "active",
        });
        await enrollment.save();
      }

      // Redirect to success page with relevant IDs
      return res.redirect(
        `${FRONTEND_SUCCESS_URL}?subjectId=${payment.subject_id}&paymentId=${payment._id}&refId=${refId}`
      );
    } else {
      // Verification failed or payment was unsuccessful
      return res.redirect(
        `${FRONTEND_FAILURE_URL}?msg=PaymentVerificationFailed&uuid=${orderId}`
      );
    }
  } catch (error) {
    console.error("Error during verification and enrollment:", error);
    return res.redirect(`${FRONTEND_FAILURE_URL}?msg=InternalServerError`);
  }
};

// -----------------------------------------------------------
// 5. ADMIN CRUD OPERATIONS
// -----------------------------------------------------------

// GET all payments
export const getPayments = async (req, res) => {
  try {
    const payments = await Payment.find().populate("user_id", "name email");
    res.json(payments);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// GET payment by ID
export const getPaymentById = async (req, res) => {
  try {
    const paymentId = req.params.id;
    const userId = req.auth._id;
    const userRole = req.auth.role;

    const payment = await Payment.findById(paymentId).populate(
      "user_id",
      "name email"
    );
    if (!payment) return res.status(404).json({ error: "Payment not found" });

    if (
      userRole !== "admin" &&
      payment.user_id._id.toString() !== userId.toString()
    ) {
      return res
        .status(403)
        .json({ error: "Access denied. Not authorized to view this payment." });
    }

    res.json(payment);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// UPDATE payment (Admin use only)
export const updatePayment = async (req, res) => {
  try {
    const payment = await Payment.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!payment) return res.status(404).json({ error: "Payment not found" });
    res.json(payment);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// DELETE payment (Admin use only)
export const deletePayment = async (req, res) => {
  try {
    const payment = await Payment.findByIdAndDelete(req.params.id);
    if (!payment) return res.status(404).json({ error: "Payment not found" });
    res.json({ msg: "Payment deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};